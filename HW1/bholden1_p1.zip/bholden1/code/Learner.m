% For Problem 3.2, 3.3, 3.4, and 3.5
% OUTPUT - learner_label [-1,1] is learner's label
% INPUT - alg [0,1] is the algorithm used to get a label
% INPUT - x [expert label vector] expert's labels
% INPUT - w [expert weight vector] expert's weights
function [learner_label] = Learner(alg,x,w)
learner_label = 0;
    if(alg==0)
        [learner_label] = WMA(x,w);
    else
        [learner_label] = RWMA(x,w);
    end
end

function [learner_label] = WMA(x,w)
learner_label = sign(sum(x.*w));
end

function [learner_label] = RWMA(x,w)
cutoff = abs(sum((x==-1).*x.*w)); % Weight for loss
learner_label = sign(rand - cutoff);
end