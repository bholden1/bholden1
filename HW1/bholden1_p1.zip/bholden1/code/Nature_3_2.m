% For Problem 3.2, 3.3, and 3.4
% OUTPUT - true_label [-1,1] is nature's true label
% INPUT - type [0,1,2] is the how nature determines the label
% INPUT - obs [game number] is the observation nature provides
% INPUT - x [expert label vector] expert's labels
% INPUT - w [expert weight vector] expert's weights
function [true_label] = Nature_3_2(type,obs,x,w)
true_label = 0;
% type = 0 - Stochastic
if(type==0)
    true_label = sign(randi(2)-1.5); % random
end
% type = 1 - Deterministic
if(type==1)
    true_label = sign(mod(obs,3)-0.5); % win if not a 3rd game
end
% type = 2 - Adversarial
if(type==2)
    true_label = -1*sign(sum(x.*w));
end
end