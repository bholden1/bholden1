% For Problem 3.5
% OUTPUT - true_label [-1,1] is nature's true label
% INPUT - obs [game number] is the observation nature provides
function [true_label] = Nature_3_5(obs)
% Deterministic
obs1_w = 0.3; % Weight of game number
obs2_w = 0.3; % Weight of win percentage
obs3_w = 0.4; % Weight of home field advantage

obs(1) = mod(obs(1),3); % Get game number [0,1,2]

val = obs1_w*(obs(1)==0) + obs2_w*(obs(2)>0.5) + obs3_w*(obs(3)==0);
true_label = sign(val - 0.5);
end