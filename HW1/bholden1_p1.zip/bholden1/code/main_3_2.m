% Main for Problem 3.2
function [] = main_3_2()
close all;
clc;
% alg = 0 is WMA, alg = 1 is RWMA
plot_count = 1;
game_max_v = [100;500;500];
eta_v = [0.1;0.1;0.5];
for alg = 0:1
    % type = 0 is stochastic, type = 1 is deterministic, type = 2 is
    % adversarial
    for type = 0:1:2
        sub_plot_count = 1;
        figure(plot_count);
        plot_count = plot_count + 1;
        if(alg==0)
            alg_name = 'WMA';
        else
            alg_name = 'RWMA';
        end
        if(type==0)
            type_name = 'Stochastic';
        elseif(type==1)
            type_name = 'Deterministic';
        else
            type_name = 'Adversarial';
        end
        for index = 1:3
            eta = eta_v(index);
            game_max = game_max_v(index);
            % Initialize variables
            w = [1;1;1];
            % Normalize weights
            w = w./sqrt(sum(w.*w));
            x_loss = zeros(1,3);
            x_loss_v = zeros(game_max,3);
            loss = 0;
            loss_v = zeros(game_max,1);
            games = 1:game_max;
            for game_num = 1:game_max
                % Get Observation
                obs = game_num; % What game number it is

                % Get Expert Advice
                x = [0;0;0];
                x(1) = 1; % Tartan Fan
                x(2) = -1; % Pessimist
                x(3) = mod(game_num,2); 
                if(x(3)==1) % Odd Games Are Lost
                    x(3) = -1;
                else % Even Games Are Won
                    x(3) = 1;
                end
                % Get Nature's Label
                true_label = Nature_3_2(type,obs,x,w);

                % Learner Makes a Prediction
                [learner_label] = Learner(alg,w,x);

                % Learner suffers a loss and updates expert weight
                loss = loss + (learner_label~=true_label);
                loss_v(game_num) = loss;
                x_loss = x_loss + (x~=true_label)';
                x_loss_v(game_num,:) = x_loss;
                w = w.*(1-eta*(x~=true_label));
            end
            subplot(3,2,sub_plot_count)
            plot(games,loss_v)
            title(sprintf('Loss For: Eta = %.1f NumOfGames = %i',eta,game_max));
            
            [~,in] = min(x_loss_v(game_max,:));
            regret_v = loss_v - x_loss_v(:,in);
            subplot(3,2,sub_plot_count+1)
            plot(games,regret_v)
            title(sprintf('Regret For: Eta = %.1f NumOfGames = %i',eta,game_max));
            fprintf('Alg = %s/%i Nature = %s/%i Eta = %.1f NumOfGames = %i\n',alg_name,alg,type_name,type,eta,game_max)
            sub_plot_count = sub_plot_count + 2;
        end
        suptitle(sprintf('Alg = %s Nature = %s',alg_name,type_name));    
    end
end
end