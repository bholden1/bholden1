% Main for Problem 3.5
function [] = main_3_5()
close all;
clc;
% alg = 0 is WMA, alg = 1 is RWMA
plot_count = 1;
game_max_v = [100;500;500];
eta_v = [0.1;0.1;0.5];
for alg = 0:1
    sub_plot_count = 1;
    figure(plot_count)
    plot_count = plot_count + 1;
    if(alg==0)
        alg_name = 'WMA';
    else
        alg_name = 'RWMA';
    end
    type_name = 'Deterministic';
    for index = 1:3
        eta = eta_v(index);
        game_max = game_max_v(index);
        % Initialize variables
        w = [1;1;1;1;1;1];
        % Normalize weights
        w = w./sqrt(sum(w.*w));
        x_loss = zeros(1,6);
        x_loss_v = zeros(game_max,6);
        loss = 0;
        loss_v = zeros(game_max,1);
        wins = 0;
        games = 1:game_max;
        for game_num = 1:game_max
            % Get Observation
            obs(1) = game_num; % What game number it is
            obs(2) = wins/game_num; % Win Percentage
            obs(3) = randi(2)-1; % Home (0) or Away (1)

            % Get Expert Advice
            x = [0;0;0;0;0;0];
            x(1) = 1; % Mr. Tartan Fan
            x(2) = -1; % Mrs. Pessimist
            x(3) = mod(game_num,2); % Mrs. Switcher
            if(x(3)==1) % Odd Games Are Lost
                x(3) = -1;
            else % Even Games Are Won
                x(3) = 1;
            end
            x(4) = sign(obs(2) - 0.5); % Mrs. Win Precentage
            x(5) = 0; % Mr. Home Field Advantage
            if(obs(3) == 0)
                x(5) = 1;
            else
                x(5) = -1;
            end
            x(6) = sign(obs(2)*0.8 + (obs(3)==0)*0.2 - 0.5); % Mr. Math

            % Get Nature's Label
            true_label = Nature_3_5(obs);

            % Learner Makes a Prediction
            [learner_label] = Learner(alg,w,x);

            % Learner suffers a loss and updates expert weight
            loss = loss + (learner_label~=true_label);
            loss_v(game_num) = loss;
            x_loss = x_loss + (x~=true_label)';
            x_loss_v(game_num,:) = x_loss;
            w = w.*(1-eta*(x~=true_label));

            wins = wins + (1==true_label);
        end
        subplot(3,2,sub_plot_count)
        plot(games,loss_v)
        title(sprintf('Loss For: Eta = %.1f NumOfGames = %i',eta,game_max));
        
        [~,in] = min(x_loss_v(game_max,:));
        regret_v = loss_v - x_loss_v(:,in);
        subplot(3,2,sub_plot_count+1)
        plot(games,regret_v)
        title(sprintf('Regret For: Eta = %.1f NumOfGames = %i',eta,game_max));
        fprintf('Alg = %s/%i Eta = %.1f NumOfGames = %i\n',alg_name,alg,eta,game_max)
        sub_plot_count = sub_plot_count + 2;
    end
    suptitle(sprintf('Alg = %s Nature = %s',alg_name,type_name));
end
end